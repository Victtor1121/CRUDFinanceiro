<?php
require_once 'db_connect.php';
if (session_status() === PHP_SESSION_NONE) session_start();

if (!isset($_SESSION['usuario_id'])) {
  http_response_code(401);
  exit('Usuário não autenticado.');
}

$usuario_id = $_SESSION['usuario_id'];
$today = date('Y-m-d');

$tipo = $_POST['tipo'] ?? ''; // 'ganho' ou 'perda'
$valor = floatval($_POST['valor'] ?? 0);
$mult = $_POST['mult'] ?? null;

if ($valor <= 0 || !$tipo) {
  http_response_code(400);
  exit('Dados inválidos.');
}

try {
  $pdo->beginTransaction();

  if ($tipo === 'ganho') {
    $desc = "Ganho Crash (" . number_format($mult, 2, ',', '.') . "x)";
    $sql = "INSERT INTO transacoes (usuario_id, categoria_id, tipo, descricao, valor, data_transacao)
            VALUES (?, 2, 'receita', ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$usuario_id, $desc, $valor, $today]);
  } elseif ($tipo === 'perda') {
    $desc = "Perda Crash";
    $sql = "INSERT INTO transacoes (usuario_id, categoria_id, tipo, descricao, valor, data_transacao)
            VALUES (?, 2, 'despesa', ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$usuario_id, $desc, $valor, $today]);
  }

  $pdo->commit();
  echo "ok";
} catch (Exception $e) {
  $pdo->rollBack();
  http_response_code(500);
  echo "Erro: " . $e->getMessage();
}
